
const Footer = () => {
    return(
        <div className="footer">
            <footer>
               <p className="footer_text">washy &copy; Tom Hein 2022</p> 
            </footer>
        </div>
    )
}

export default Footer;