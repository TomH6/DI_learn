import Header from './Header';
import './styles/About.css';

const About = (props) => {
    return (
        <>
            <Header />
            <div className="main">
                <div className="about_cont">
                    <h2 className="about_header">Who are we?</h2>
                    <p> 
                        Nothin' from nothin' leaves nothin' <br/>
                        You gotta have somethin' if you wanna be with me <br/>
                        I'm not tryin' to be your hero <br/>
                        'Cause that zero is too cold for me (Brr) <br/>
                        I'm not tryin' to be your highness <br/>
                        'Cause that minus is too low to see, yeah <br/>
                        Nothin' from nothin' leaves nothin' <br/>
                        And I'm not stuffin', believe you me <br/>
                        Don't you remember I told ya <br/>
                        I'm a soldier in the war on poverty, yeah
                        Yes, I am <br/>
                        Nothin' from nothin' leaves nothin' <br/>
                        You gotta have somethin' if you wanna be with me <br/>
                        Nothin' from nothin' leaves nothin' <br/>
                        You gotta have somethin' if you wanna be with me <br/>
                        That's right, ha, yeah <br/>
                        Gotta have somethin' if you wanna be with me
                        You gotta bring me somethin' girl
                        If you wanna be with me
                    </p>
                </div>
            </div>
        </>
    )
}
export default About;

