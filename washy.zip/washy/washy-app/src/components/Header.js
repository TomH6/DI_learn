
const Header = () => {
    return(
        <div style={{display: 'flex', flexDirection:'column' ,alignItems: 'center', paddingTop: 30}}>
            <h1 style={{color: "navy"}}>WASHY</h1>
            {/* <h2 style={{color: "navy"}}>keeping it clean</h2> */}
        </div>
    )
};

export default Header;