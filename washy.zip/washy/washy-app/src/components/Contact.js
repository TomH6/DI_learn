
const Contact = (props) => {

  return (
    <>
      <h1>Contact us</h1>
    </>
   
  );
}
export default Contact;
